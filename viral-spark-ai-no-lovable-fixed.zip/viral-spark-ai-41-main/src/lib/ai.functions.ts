import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { generateText } from "ai";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createLovableAiGatewayProvider } from "./ai-gateway";

const InputSchema = z.object({
  type: z.enum([
    "hook", "caption", "hashtag", "script", "thumbnail", "trending", "title",
  ]),
  params: z.record(z.string(), z.string()).default({}),
});

const PROMPTS: Record<string, (p: Record<string, string>) => string> = {
  hook: (p) =>
    `Generate 10 highly viral short-form video hooks for the topic "${p.topic || "general"}".
Style: ${p.style || "Clickbait"}. Language: ${p.language || "English"}.
Each hook MUST be 1 sentence, under 15 words, attention-grabbing, scroll-stopping.
Return as a numbered list 1-10. No preamble, no explanations.`,
  caption: (p) =>
    `Write 6 viral ${p.platform || "Instagram"} captions for a reel about "${p.topic || ""}".
Mood: ${p.mood || "energetic"}. Use emojis naturally, include 1 CTA per caption.
Return numbered list 1-6. No preamble.`,
  hashtag: (p) =>
    `Generate hashtags for the niche "${p.topic || "content creator"}" on ${p.platform || "Instagram"}.
Return 4 sections, each with 8 tags on one line space-separated:
**Trending**
**Niche**
**High Reach**
**Low Competition**
No preamble.`,
  script: (p) =>
    `Write a viral short-form video script about "${p.topic || ""}" with target duration ${p.duration || "60 sec"}.
Structure with these exact headings on their own lines, then content under each:
**Hook (first 3s)**
**Main Content**
**CTA / Ending**
**Engagement Question**
Keep tight, energetic, ready to record.`,
  thumbnail: (p) =>
    `Generate 10 high-CTR thumbnail text overlays for a video about "${p.topic || ""}".
Mix Hindi + English (Hinglish) when relevant. Use ALL CAPS for emphasis words. Each line under 6 words. Numbered list.`,
  trending: (p) =>
    `List today's 12 trending viral content ideas for ${p.niche || "general"} creators on short-form platforms.
For each: title (bold) + 1-line description. Numbered list 1-12. No preamble.`,
  title: (p) =>
    `Generate 10 high-CTR YouTube titles about "${p.topic || ""}".
Each under 60 chars, emotional hook, curiosity gap, no clickbait lies. Numbered list.`,
};

export const generateContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => InputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "AI service not configured." };
    }

    const prompt = PROMPTS[data.type](data.params);

    try {
      const gateway = createLovableAiGatewayProvider(apiKey);
      const { text } = await generateText({
        model: gateway("google/gemini-3-flash-preview"),
        system:
          "You are ViralAI, an expert short-form content strategist. Output ONLY the requested content. No greetings, no explanations.",
        prompt,
      });

      // Save to history
      const { supabase, userId } = context;
      await supabase.from("generations").insert({
        user_id: userId,
        type: data.type,
        input: data.params,
        output: text,
      });

      return { ok: true as const, text };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.includes("429")) return { ok: false as const, error: "Rate limit hit — please wait a moment." };
      if (msg.includes("402")) return { ok: false as const, error: "AI credits exhausted. Add credits in Workspace Settings." };
      return { ok: false as const, error: "Generation failed. Please try again." };
    }
  });
