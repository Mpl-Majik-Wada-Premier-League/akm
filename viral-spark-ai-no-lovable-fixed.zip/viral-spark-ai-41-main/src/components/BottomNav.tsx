import { Link, useLocation } from "@tanstack/react-router";
import { Home, Sparkles, History, User } from "lucide-react";

const items = [
  { to: "/dashboard", label: "Home", Icon: Home },
  { to: "/create", label: "Create", Icon: Sparkles },
  { to: "/history", label: "History", Icon: History },
  { to: "/profile", label: "Profile", Icon: User },
];

export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-md px-4 pb-3">
        <div className="glass-strong rounded-2xl px-2 py-2 flex justify-between">
          {items.map(({ to, label, Icon }) => {
            const active = pathname === to || (to === "/create" && pathname.startsWith("/generate"));
            return (
              <Link
                key={to}
                to={to}
                className={`flex-1 flex flex-col items-center gap-0.5 py-2 rounded-xl transition-all ${
                  active ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                <div className={`p-1.5 rounded-lg ${active ? "gradient-bg glow" : ""}`}>
                  <Icon className="size-4" />
                </div>
                <span className="text-[10px] font-medium">{label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
