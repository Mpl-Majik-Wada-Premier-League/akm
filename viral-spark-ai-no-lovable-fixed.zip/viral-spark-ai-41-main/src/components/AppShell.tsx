import type { ReactNode } from "react";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen pb-28">
      <FloatingBlobs />
      <div className="relative mx-auto max-w-md px-4 pt-6">{children}</div>
    </div>
  );
}

export function FloatingBlobs() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute -top-20 -left-10 size-72 rounded-full bg-primary/30 blur-3xl animate-blob" />
      <div className="absolute top-40 -right-20 size-80 rounded-full bg-[color:var(--glow)]/20 blur-3xl animate-blob" style={{ animationDelay: "2s" }} />
      <div className="absolute bottom-10 left-1/3 size-72 rounded-full bg-secondary/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
    </div>
  );
}
