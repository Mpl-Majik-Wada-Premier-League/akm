import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Copy, RefreshCw, Sparkles, Share2 } from "lucide-react";
import { generateContent } from "@/lib/ai.functions";

export type Field =
  | { name: string; label: string; type: "text"; placeholder?: string }
  | { name: string; label: string; type: "select"; options: string[] };

type Props = {
  type: "hook" | "caption" | "hashtag" | "script" | "thumbnail" | "trending" | "title";
  title: string;
  emoji: string;
  description: string;
  fields: Field[];
  initial?: Record<string, string>;
};

export function GeneratorView({ type, title, emoji, description, fields, initial }: Props) {
  const generate = useServerFn(generateContent);
  const [params, setParams] = useState<Record<string, string>>(() => {
    const seed: Record<string, string> = { ...initial };
    fields.forEach((f) => {
      if (!seed[f.name]) seed[f.name] = f.type === "select" ? f.options[0] : "";
    });
    return seed;
  });
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);

  const run = async () => {
    setLoading(true);
    setOutput("");
    try {
      const res = await generate({ data: { type, params } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      // typing animation
      const text = res.text;
      let i = 0;
      const step = Math.max(2, Math.floor(text.length / 120));
      const id = setInterval(() => {
        i += step;
        setOutput(text.slice(0, i));
        if (i >= text.length) {
          clearInterval(id);
          setOutput(text);
        }
      }, 20);
    } catch (e) {
      toast.error("Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const copy = async () => {
    await navigator.clipboard.writeText(output);
    toast.success("Copied to clipboard ✨");
  };

  const share = async () => {
    if (navigator.share) {
      try { await navigator.share({ text: output, title: `ViralAI · ${title}` }); } catch {}
    } else {
      copy();
    }
  };

  return (
    <div className="space-y-5">
      <header className="flex items-center gap-3">
        <Link to="/dashboard" className="size-10 rounded-xl glass flex items-center justify-center">
          <ArrowLeft className="size-4" />
        </Link>
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <span className="text-2xl">{emoji}</span>
            <span className="gradient-text">{title}</span>
          </h1>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </header>

      <div className="glass-strong rounded-2xl p-4 space-y-3">
        {fields.map((f) => (
          <div key={f.name}>
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{f.label}</label>
            {f.type === "text" ? (
              <input
                value={params[f.name] || ""}
                onChange={(e) => setParams((p) => ({ ...p, [f.name]: e.target.value }))}
                placeholder={f.placeholder}
                className="mt-1 w-full bg-input/60 border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/60"
              />
            ) : (
              <select
                value={params[f.name] || f.options[0]}
                onChange={(e) => setParams((p) => ({ ...p, [f.name]: e.target.value }))}
                className="mt-1 w-full bg-input/60 border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/60"
              >
                {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            )}
          </div>
        ))}
        <button onClick={run} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60">
          {loading ? <RefreshCw className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
          {loading ? "Generating..." : "Generate"}
        </button>
      </div>

      {output && (
        <div className="glass rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider text-muted-foreground">Output</span>
            <div className="flex gap-2">
              <button onClick={run} className="btn-ghost !py-1.5 !px-3 text-xs flex items-center gap-1"><RefreshCw className="size-3" />Regen</button>
              <button onClick={copy} className="btn-ghost !py-1.5 !px-3 text-xs flex items-center gap-1"><Copy className="size-3" />Copy</button>
              <button onClick={share} className="btn-ghost !py-1.5 !px-3 text-xs flex items-center gap-1"><Share2 className="size-3" />Share</button>
            </div>
          </div>
          <pre className="whitespace-pre-wrap text-sm leading-relaxed font-sans">{output}</pre>
        </div>
      )}
    </div>
  );
}
