import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/splash")({ component: Splash });

function Splash() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  useEffect(() => {
    const t = setTimeout(() => {
      if (loading) return;
      navigate({ to: user ? "/dashboard" : "/login" });
    }, 1800);
    return () => clearTimeout(t);
  }, [navigate, user, loading]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <div className="relative">
        <div className="size-28 rounded-3xl gradient-bg flex items-center justify-center animate-pulse-glow">
          <Sparkles className="size-12 text-white" />
        </div>
        <div className="absolute inset-0 rounded-3xl animate-shimmer" />
      </div>
      <h1 className="mt-8 text-4xl font-bold gradient-text">ViralAI</h1>
      <p className="mt-2 text-muted-foreground">Create Viral Content Faster</p>
      <div className="mt-10 flex gap-1">
        {[0, 1, 2].map((i) => (
          <span key={i} className="size-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: `${i * 200}ms` }} />
        ))}
      </div>
    </div>
  );
}
