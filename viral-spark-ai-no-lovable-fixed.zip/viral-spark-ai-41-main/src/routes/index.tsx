import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Sparkles, Zap, Hash, Video, Image as ImageIcon, TrendingUp, Youtube,
  Check, Star, ArrowRight, Quote,
} from "lucide-react";
import { FloatingBlobs } from "@/components/AppShell";

export const Route = createFileRoute("/")({ component: Landing });

const features = [
  { Icon: Zap, title: "Viral Hook Generator", desc: "10 scroll-stopping hooks in seconds." },
  { Icon: Sparkles, title: "Caption Generator", desc: "Reel-ready captions with emojis & CTAs." },
  { Icon: Hash, title: "Hashtag Generator", desc: "Trending + low-comp hashtags for reach." },
  { Icon: Video, title: "Shorts Script", desc: "Hook → main → CTA in 30s / 60s / 2m." },
  { Icon: ImageIcon, title: "Thumbnail Text", desc: "High-CTR overlays, Hinglish supported." },
  { Icon: TrendingUp, title: "Trending Ideas", desc: "Today's viral topics, niche-tuned." },
  { Icon: Youtube, title: "YouTube Titles", desc: "Curiosity-gap titles under 60 chars." },
];

const testimonials = [
  { name: "Aarav S.", role: "Reels Creator · 480K", text: "Went from 12K views avg to 1.2M in 6 weeks. The hooks slap." },
  { name: "Mira K.", role: "YouTuber · 220K", text: "Title generator alone paid for the year. Best AI tool I use daily." },
  { name: "Devon L.", role: "Shorts Creator", text: "ViralAI is basically my content strategist. Insanely fast." },
];

const faqs = [
  { q: "Is ViralAI free?", a: "Yes — 10 generations/day on the free plan. Go premium for unlimited." },
  { q: "Which platforms?", a: "Instagram Reels, YouTube, YouTube Shorts, and TikTok." },
  { q: "Do I own the content?", a: "100%. Everything generated is yours — commercial use included." },
  { q: "Languages?", a: "English, Hindi, Hinglish, Spanish, and more." },
];

function Landing() {
  return (
    <div className="relative">
      <FloatingBlobs />

      {/* Nav */}
      <nav className="sticky top-0 z-30 backdrop-blur-xl bg-background/60 border-b border-border/40">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg">
            <span className="size-8 rounded-xl gradient-bg glow flex items-center justify-center">
              <Sparkles className="size-4 text-white" />
            </span>
            <span className="gradient-text">ViralAI</span>
          </Link>
          <Link to="/login" className="btn-primary !py-2 !px-4 text-sm">Get Started</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="px-5 pt-16 pb-20 text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs mb-6">
          <span className="size-1.5 rounded-full bg-secondary animate-pulse" />
          Powered by Gemini · used by 12K+ creators
        </div>
        <h1 className="text-5xl md:text-7xl font-bold leading-[1.05] tracking-tight">
          Create <span className="gradient-text">viral content</span><br />faster than the trend.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto">
          AI-powered hooks, captions, scripts, hashtags, and thumbnail text — built for Reels, Shorts, and YouTube.
        </p>
        <div className="mt-8 flex flex-wrap gap-3 justify-center">
          <Link to="/login" className="btn-primary inline-flex items-center gap-2">
            Start free <ArrowRight className="size-4" />
          </Link>
          <a href="#features" className="btn-ghost">See features</a>
        </div>
        <div className="mt-10 flex items-center justify-center gap-1 text-sm">
          {[...Array(5)].map((_, i) => <Star key={i} className="size-4 fill-[color:var(--glow)] text-[color:var(--glow)]" />)}
          <span className="ml-2 text-muted-foreground">4.9 · 2,400+ creators</span>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="px-5 py-20 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">Everything you need to <span className="gradient-text">go viral</span></h2>
          <p className="mt-3 text-muted-foreground">7 AI tools, one tap away.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map(({ Icon, title, desc }) => (
            <div key={title} className="glass-strong rounded-2xl p-5 hover:ring-glow transition-all">
              <div className="size-11 rounded-xl gradient-bg flex items-center justify-center mb-4 glow">
                <Icon className="size-5 text-white" />
              </div>
              <h3 className="font-semibold">{title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Social proof / Testimonials */}
      <section className="px-5 py-20 max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Creators <span className="gradient-text">love</span> ViralAI</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {testimonials.map((t) => (
            <div key={t.name} className="glass-strong rounded-2xl p-5">
              <Quote className="size-5 text-[color:var(--glow)] mb-3" />
              <p className="text-sm leading-relaxed">{t.text}</p>
              <div className="mt-4 pt-4 border-t border-border/40">
                <div className="font-semibold text-sm">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="px-5 py-20 max-w-5xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Simple <span className="gradient-text">pricing</span></h2>
        <div className="grid md:grid-cols-2 gap-5">
          {[
            { name: "Free", price: "$0", tag: "Forever", features: ["10 generations / day", "All 7 AI tools", "History & favorites", "Email support"] },
            { name: "Premium", price: "$9", tag: "/ month", popular: true, features: ["Unlimited generations", "Faster AI responses", "Premium templates", "Priority support", "No ads"] },
          ].map((p) => (
            <div key={p.name} className={`relative glass-strong rounded-2xl p-6 ${p.popular ? "ring-glow" : ""}`}>
              {p.popular && <span className="absolute -top-3 left-6 px-3 py-1 rounded-full text-xs font-semibold gradient-bg">Most popular</span>}
              <h3 className="text-xl font-bold">{p.name}</h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-bold">{p.price}</span>
                <span className="text-muted-foreground text-sm">{p.tag}</span>
              </div>
              <ul className="mt-5 space-y-2">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <Check className="size-4 text-secondary" />{f}
                  </li>
                ))}
              </ul>
              <Link to="/login" className={`mt-6 inline-flex w-full justify-center ${p.popular ? "btn-primary" : "btn-ghost"}`}>
                Get {p.name}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="px-5 py-20 max-w-3xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Frequently asked</h2>
        <div className="space-y-3">
          {faqs.map((f) => (
            <details key={f.q} className="glass rounded-2xl p-5 group">
              <summary className="font-semibold cursor-pointer list-none flex justify-between items-center">
                {f.q}
                <span className="text-muted-foreground group-open:rotate-45 transition-transform text-xl">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-5 py-20">
        <div className="max-w-4xl mx-auto glass-strong rounded-3xl p-10 text-center relative overflow-hidden">
          <div className="absolute inset-0 -z-10 opacity-40" style={{ background: "var(--gradient-radial)" }} />
          <h2 className="text-3xl md:text-5xl font-bold">Your next viral post is <span className="gradient-text">one tap away</span>.</h2>
          <p className="mt-4 text-muted-foreground">Join thousands of creators using ViralAI every day.</p>
          <Link to="/login" className="btn-primary inline-flex items-center gap-2 mt-8">
            Start creating free <ArrowRight className="size-4" />
          </Link>
        </div>
      </section>

      <footer className="px-5 py-10 text-center text-sm text-muted-foreground border-t border-border/40">
        © {new Date().getFullYear()} ViralAI · Create Viral Content Faster
      </footer>
    </div>
  );
}
