import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Crown, LogOut, Sparkles, Flame } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { BottomNav } from "@/components/BottomNav";
import { RequireAuth } from "@/components/RequireAuth";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/profile")({ component: () => <RequireAuth><Profile /></RequireAuth> });

function Profile() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    supabase.from("generations").select("id", { count: "exact", head: true })
      .then(({ count }) => setCount(count || 0));
  }, [user]);

  return (
    <>
      <AppShell>
        <header className="mb-5">
          <h1 className="text-2xl font-bold">Profile</h1>
        </header>

        <div className="glass-strong rounded-2xl p-6 text-center">
          <div className="size-20 rounded-2xl gradient-bg mx-auto flex items-center justify-center glow">
            <span className="text-3xl font-bold text-white">{user?.email?.[0]?.toUpperCase()}</span>
          </div>
          <h2 className="mt-4 text-lg font-bold">{user?.email?.split("@")[0]}</h2>
          <p className="text-xs text-muted-foreground">{user?.email}</p>
          <div className="mt-3 inline-flex items-center gap-1 px-3 py-1 rounded-full glass text-xs">
            <Sparkles className="size-3 text-[color:var(--glow)]" /> Free plan
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="glass rounded-2xl p-4">
            <Flame className="size-5 text-[color:var(--glow)]" />
            <div className="mt-2 text-2xl font-bold">{count}</div>
            <div className="text-xs text-muted-foreground">Generations</div>
          </div>
          <div className="glass rounded-2xl p-4">
            <Crown className="size-5 text-[color:var(--glow)]" />
            <div className="mt-2 text-2xl font-bold">—</div>
            <div className="text-xs text-muted-foreground">Streak (soon)</div>
          </div>
        </div>

        <Link to="/premium" className="mt-4 block glass-strong rounded-2xl p-4 ring-glow">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl gradient-bg flex items-center justify-center glow">
              <Crown className="size-5 text-white" />
            </div>
            <div className="flex-1">
              <div className="font-semibold">Upgrade to Premium</div>
              <div className="text-xs text-muted-foreground">Unlimited generations · faster AI</div>
            </div>
            <span>→</span>
          </div>
        </Link>

        <Link to="/admin" className="mt-3 block glass rounded-2xl p-4 text-sm text-muted-foreground">
          Admin panel →
        </Link>

        <button
          onClick={async () => { await signOut(); navigate({ to: "/" }); }}
          className="btn-ghost w-full mt-4 flex items-center justify-center gap-2 text-destructive"
        >
          <LogOut className="size-4" /> Log out
        </button>
      </AppShell>
      <BottomNav />
    </>
  );
}
