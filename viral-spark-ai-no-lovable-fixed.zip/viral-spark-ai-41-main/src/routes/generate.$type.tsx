import { createFileRoute, notFound } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { BottomNav } from "@/components/BottomNav";
import { RequireAuth } from "@/components/RequireAuth";
import { GeneratorView, type Field } from "@/components/GeneratorView";

type Cfg = {
  type: "hook" | "caption" | "hashtag" | "script" | "thumbnail" | "trending" | "title";
  title: string;
  emoji: string;
  description: string;
  fields: Field[];
};

const CFG: Record<string, Cfg> = {
  hook: {
    type: "hook", title: "Viral Hook Generator", emoji: "⚡",
    description: "10 scroll-stopping hooks for your next post.",
    fields: [
      { name: "topic", label: "Topic", type: "text", placeholder: "e.g. fitness for busy parents" },
      { name: "language", label: "Language", type: "select", options: ["English", "Hindi", "Hinglish", "Spanish"] },
      { name: "style", label: "Style", type: "select", options: ["Clickbait", "Funny", "Emotional", "Dark", "Motivational", "Storytelling"] },
    ],
  },
  caption: {
    type: "caption", title: "Caption Generator", emoji: "✨",
    description: "Reel-ready captions with emojis & CTAs.",
    fields: [
      { name: "topic", label: "Reel topic", type: "text", placeholder: "e.g. morning routine glow-up" },
      { name: "mood", label: "Mood", type: "select", options: ["Energetic", "Calm", "Funny", "Inspirational", "Bold"] },
      { name: "platform", label: "Platform", type: "select", options: ["Instagram", "YouTube", "TikTok"] },
    ],
  },
  hashtag: {
    type: "hashtag", title: "Hashtag Generator", emoji: "#️⃣",
    description: "Trending + niche + low-comp hashtags.",
    fields: [
      { name: "topic", label: "Niche", type: "text", placeholder: "e.g. food creator" },
      { name: "platform", label: "Platform", type: "select", options: ["Instagram", "TikTok", "YouTube"] },
    ],
  },
  script: {
    type: "script", title: "Shorts Script Generator", emoji: "🎬",
    description: "Hook → Main → CTA, ready to record.",
    fields: [
      { name: "topic", label: "Topic", type: "text", placeholder: "e.g. side hustle ideas" },
      { name: "duration", label: "Duration", type: "select", options: ["30 sec", "60 sec", "2 min"] },
    ],
  },
  thumbnail: {
    type: "thumbnail", title: "Thumbnail Text Generator", emoji: "🖼️",
    description: "Emotional, bold, high-CTR overlays.",
    fields: [
      { name: "topic", label: "Video topic", type: "text", placeholder: "e.g. iPhone 17 review" },
    ],
  },
  title: {
    type: "title", title: "YouTube Title Generator", emoji: "📺",
    description: "Curiosity-gap titles under 60 chars.",
    fields: [
      { name: "topic", label: "Topic", type: "text", placeholder: "e.g. AI agents in 2026" },
    ],
  },
};

export const Route = createFileRoute("/generate/$type")({
  beforeLoad: ({ params }) => {
    if (!CFG[params.type]) throw notFound();
  },
  component: () => <RequireAuth><GeneratePage /></RequireAuth>,
});

function GeneratePage() {
  const { type } = Route.useParams();
  const cfg = CFG[type];
  return (
    <>
      <AppShell>
        <GeneratorView {...cfg} />
      </AppShell>
      <BottomNav />
    </>
  );
}
