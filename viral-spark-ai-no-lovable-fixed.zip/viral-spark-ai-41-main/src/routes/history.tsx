import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Copy, Trash2, Star, Sparkles } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { BottomNav } from "@/components/BottomNav";
import { RequireAuth } from "@/components/RequireAuth";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";

export const Route = createFileRoute("/history")({ component: () => <RequireAuth><History /></RequireAuth> });

type Row = { id: string; type: string; output: string; is_favorite: boolean; created_at: string; input: Record<string, unknown> };

function History() {
  const [rows, setRows] = useState<Row[] | null>(null);

  const load = async () => {
    const { data, error } = await supabase
      .from("generations")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) { toast.error("Couldn't load history"); return; }
    setRows((data || []) as Row[]);
  };

  useEffect(() => { load(); }, []);

  const remove = async (id: string) => {
    await supabase.from("generations").delete().eq("id", id);
    setRows((r) => r?.filter((x) => x.id !== id) || null);
    toast.success("Deleted");
  };

  const fav = async (r: Row) => {
    await supabase.from("generations").update({ is_favorite: !r.is_favorite }).eq("id", r.id);
    setRows((rs) => rs?.map((x) => x.id === r.id ? { ...x, is_favorite: !r.is_favorite } : x) || null);
  };

  const copy = async (t: string) => { await navigator.clipboard.writeText(t); toast.success("Copied"); };

  return (
    <>
      <AppShell>
        <header className="mb-5">
          <h1 className="text-2xl font-bold">History</h1>
          <p className="text-sm text-muted-foreground">Your saved generations.</p>
        </header>

        {rows === null && <div className="glass rounded-2xl p-8 text-center text-sm text-muted-foreground">Loading…</div>}
        {rows && rows.length === 0 && (
          <div className="glass-strong rounded-2xl p-8 text-center">
            <Sparkles className="size-8 mx-auto text-[color:var(--glow)] mb-3" />
            <p className="font-semibold">Nothing here yet</p>
            <p className="text-xs text-muted-foreground mt-1">Generate something to see it here.</p>
            <Link to="/create" className="btn-primary inline-flex mt-5">Start creating</Link>
          </div>
        )}
        <div className="space-y-3">
          {rows?.map((r) => (
            <div key={r.id} className="glass rounded-2xl p-4">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="uppercase tracking-wider font-semibold text-[color:var(--glow)]">{r.type}</span>
                <span>{formatDistanceToNow(new Date(r.created_at), { addSuffix: true })}</span>
              </div>
              <pre className="mt-2 whitespace-pre-wrap text-sm font-sans line-clamp-6">{r.output}</pre>
              <div className="mt-3 flex gap-2">
                <button onClick={() => copy(r.output)} className="btn-ghost !py-1.5 !px-3 text-xs flex items-center gap-1"><Copy className="size-3" />Copy</button>
                <button onClick={() => fav(r)} className="btn-ghost !py-1.5 !px-3 text-xs flex items-center gap-1">
                  <Star className={`size-3 ${r.is_favorite ? "fill-[color:var(--glow)] text-[color:var(--glow)]" : ""}`} />Save
                </button>
                <button onClick={() => remove(r.id)} className="btn-ghost !py-1.5 !px-3 text-xs flex items-center gap-1 ml-auto text-destructive"><Trash2 className="size-3" />Delete</button>
              </div>
            </div>
          ))}
        </div>
      </AppShell>
      <BottomNav />
    </>
  );
}
