import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Crown, ArrowLeft, Gift } from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/premium")({ component: Premium });

function Premium() {
  return (
    <AppShell>
      <header className="flex items-center gap-3 mb-5">
        <Link to="/dashboard" className="size-10 rounded-xl glass flex items-center justify-center">
          <ArrowLeft className="size-4" />
        </Link>
        <h1 className="text-xl font-bold">Premium</h1>
      </header>

      <div className="glass-strong rounded-3xl p-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 -z-10 opacity-50" style={{ background: "var(--gradient-radial)" }} />
        <div className="size-16 rounded-2xl gradient-bg mx-auto flex items-center justify-center animate-pulse-glow">
          <Crown className="size-7 text-white" />
        </div>
        <h2 className="mt-4 text-2xl font-bold">Go <span className="gradient-text">Unlimited</span></h2>
        <p className="text-sm text-muted-foreground">$9 / month · cancel anytime</p>
        <ul className="mt-5 space-y-2 text-left text-sm max-w-xs mx-auto">
          {["Unlimited generations","Faster AI responses","Premium templates","Priority support","No ads"].map((f) => (
            <li key={f} className="flex items-center gap-2"><Check className="size-4 text-secondary" />{f}</li>
          ))}
        </ul>
        <button className="btn-primary w-full mt-6">Upgrade now</button>
        <p className="mt-3 text-[10px] text-muted-foreground">Payments coming soon. Tap to join the waitlist.</p>
      </div>

      <div className="mt-5 glass rounded-2xl p-5">
        <div className="flex items-center gap-3">
          <Gift className="size-5 text-[color:var(--glow)]" />
          <div>
            <div className="font-semibold">Referral Rewards</div>
            <div className="text-xs text-muted-foreground">Invite 3 friends, get 1 month free.</div>
          </div>
        </div>
      </div>

      {/* Ad placeholder */}
      <div className="mt-4 glass rounded-2xl p-5 text-center text-xs text-muted-foreground border-dashed">
        Ad space · upgrade to remove
      </div>
    </AppShell>
  );
}
