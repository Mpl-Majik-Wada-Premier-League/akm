import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { BottomNav } from "@/components/BottomNav";
import { RequireAuth } from "@/components/RequireAuth";
import { GeneratorView } from "@/components/GeneratorView";

export const Route = createFileRoute("/trending")({ component: () => <RequireAuth><Trending /></RequireAuth> });

function Trending() {
  return (
    <>
      <AppShell>
        <GeneratorView
          type="trending"
          title="Trending Ideas"
          emoji="🔥"
          description="AI-curated viral topics for today."
          fields={[
            { name: "niche", label: "Your niche", type: "text", placeholder: "e.g. tech reviews, fitness, food" },
          ]}
          initial={{ niche: "general" }}
        />
      </AppShell>
      <BottomNav />
    </>
  );
}
