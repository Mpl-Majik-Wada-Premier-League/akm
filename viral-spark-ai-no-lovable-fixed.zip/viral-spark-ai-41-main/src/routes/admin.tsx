import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { ArrowLeft, Users, Sparkles, Bell, Lock } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin")({ component: Admin });

function Admin() {
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [stats, setStats] = useState<{ users: number; gens: number }>({ users: 0, gens: 0 });
  const [announce, setAnnounce] = useState("");

  useEffect(() => {
    if (!authed) return;
    Promise.all([
      supabase.from("profiles").select("id", { count: "exact", head: true }),
      supabase.from("generations").select("id", { count: "exact", head: true }),
    ]).then(([u, g]) => setStats({ users: u.count || 0, gens: g.count || 0 }));
  }, [authed]);

  if (!authed) {
    return (
      <AppShell>
        <header className="flex items-center gap-3 mb-5">
          <Link to="/dashboard" className="size-10 rounded-xl glass flex items-center justify-center">
            <ArrowLeft className="size-4" />
          </Link>
          <h1 className="text-xl font-bold">Admin</h1>
        </header>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (pw === "Abhi18") setAuthed(true);
            else toast.error("Wrong password");
          }}
          className="glass-strong rounded-2xl p-6"
        >
          <Lock className="size-6 text-[color:var(--glow)] mx-auto" />
          <p className="text-center text-sm mt-3">Admin access</p>
          <input
            type="password"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            placeholder="Password"
            className="mt-4 w-full bg-input/60 border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/60"
          />
          <button className="btn-primary w-full mt-3">Enter</button>
        </form>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <header className="flex items-center gap-3 mb-5">
        <Link to="/dashboard" className="size-10 rounded-xl glass flex items-center justify-center">
          <ArrowLeft className="size-4" />
        </Link>
        <h1 className="text-xl font-bold">Admin Panel</h1>
      </header>

      <div className="grid grid-cols-2 gap-3">
        <div className="glass-strong rounded-2xl p-5">
          <Users className="size-5 text-[color:var(--glow)]" />
          <div className="mt-2 text-3xl font-bold">{stats.users}</div>
          <div className="text-xs text-muted-foreground">Total users</div>
        </div>
        <div className="glass-strong rounded-2xl p-5">
          <Sparkles className="size-5 text-[color:var(--glow)]" />
          <div className="mt-2 text-3xl font-bold">{stats.gens}</div>
          <div className="text-xs text-muted-foreground">Generations</div>
        </div>
      </div>

      <div className="mt-4 glass-strong rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-3">
          <Bell className="size-4 text-[color:var(--glow)]" />
          <h2 className="font-semibold">Send announcement</h2>
        </div>
        <textarea
          value={announce}
          onChange={(e) => setAnnounce(e.target.value)}
          rows={3}
          placeholder="Notify all users…"
          className="w-full bg-input/60 border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/60"
        />
        <button
          onClick={() => { toast.success("Announcement queued ✓"); setAnnounce(""); }}
          className="btn-primary w-full mt-3"
        >
          Send to all users
        </button>
      </div>

      <p className="mt-4 text-xs text-muted-foreground text-center">
        User & generation management beyond stats coming soon.
      </p>
    </AppShell>
  );
}
