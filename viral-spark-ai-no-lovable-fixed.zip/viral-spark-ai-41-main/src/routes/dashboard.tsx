import { createFileRoute, Link } from "@tanstack/react-router";
import { Zap, Sparkles, Hash, Video, Image as ImageIcon, TrendingUp, Youtube, Flame, Crown } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { BottomNav } from "@/components/BottomNav";
import { RequireAuth } from "@/components/RequireAuth";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/dashboard")({ component: () => <RequireAuth><Dashboard /></RequireAuth> });

const tools = [
  { to: "/generate/hook", Icon: Zap, title: "Viral Hook", color: "from-fuchsia-500 to-violet-500" },
  { to: "/generate/caption", Icon: Sparkles, title: "Caption", color: "from-cyan-400 to-blue-500" },
  { to: "/generate/hashtag", Icon: Hash, title: "Hashtags", color: "from-emerald-400 to-teal-500" },
  { to: "/generate/script", Icon: Video, title: "Shorts Script", color: "from-orange-400 to-pink-500" },
  { to: "/generate/thumbnail", Icon: ImageIcon, title: "Thumbnail Text", color: "from-yellow-400 to-orange-500" },
  { to: "/generate/title", Icon: Youtube, title: "YouTube Title", color: "from-rose-500 to-red-500" },
];

function Dashboard() {
  const { user } = useAuth();
  const name = user?.email?.split("@")[0] || "creator";
  return (
    <>
      <AppShell>
        <header className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Welcome back</p>
            <h1 className="text-2xl font-bold">Hey, <span className="gradient-text">{name}</span> 👋</h1>
          </div>
          <Link to="/premium" className="size-10 rounded-xl glass flex items-center justify-center">
            <Crown className="size-4 text-[color:var(--glow)]" />
          </Link>
        </header>

        {/* AI glow banner */}
        <div className="mt-5 relative glass-strong rounded-2xl p-5 overflow-hidden">
          <div className="absolute inset-0 -z-10 opacity-50" style={{ background: "var(--gradient-radial)" }} />
          <div className="flex items-center gap-3">
            <div className="size-12 rounded-2xl gradient-bg flex items-center justify-center animate-pulse-glow">
              <Sparkles className="size-6 text-white" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-[color:var(--glow)]">Today's trend</div>
              <h2 className="font-bold leading-tight">POV storytelling hooks are exploding 🔥</h2>
            </div>
          </div>
          <Link to="/trending" className="mt-4 inline-flex text-sm font-semibold text-[color:var(--glow)]">
            Explore trending →
          </Link>
        </div>

        {/* Tools grid */}
        <h2 className="mt-7 mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider">AI Tools</h2>
        <div className="grid grid-cols-2 gap-3">
          {tools.map(({ to, Icon, title, color }) => (
            <Link key={to} to={to} className="glass-strong rounded-2xl p-4 hover:ring-glow transition-all group">
              <div className={`size-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-3 group-hover:scale-105 transition`}>
                <Icon className="size-5 text-white" />
              </div>
              <div className="font-semibold text-sm">{title}</div>
              <div className="text-xs text-muted-foreground mt-0.5">Tap to generate</div>
            </Link>
          ))}
          <Link to="/trending" className="glass-strong rounded-2xl p-4 col-span-2 flex items-center gap-3 hover:ring-glow transition-all">
            <div className="size-10 rounded-xl bg-gradient-to-br from-pink-500 to-violet-500 flex items-center justify-center">
              <Flame className="size-5 text-white" />
            </div>
            <div className="flex-1">
              <div className="font-semibold text-sm">Trending Video Ideas</div>
              <div className="text-xs text-muted-foreground">AI-curated viral topics for today</div>
            </div>
            <TrendingUp className="size-4 text-muted-foreground" />
          </Link>
        </div>
      </AppShell>
      <BottomNav />
    </>
  );
}
