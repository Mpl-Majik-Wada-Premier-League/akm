import { createFileRoute, Link } from "@tanstack/react-router";
import { Zap, Sparkles, Hash, Video, Image as ImageIcon, Youtube, TrendingUp } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { BottomNav } from "@/components/BottomNav";
import { RequireAuth } from "@/components/RequireAuth";

export const Route = createFileRoute("/create")({ component: () => <RequireAuth><Create /></RequireAuth> });

const tools = [
  { to: "/generate/hook", Icon: Zap, title: "Viral Hook Generator", desc: "10 scroll-stoppers" },
  { to: "/generate/caption", Icon: Sparkles, title: "Caption Generator", desc: "Reels & posts" },
  { to: "/generate/hashtag", Icon: Hash, title: "Hashtag Generator", desc: "Trending + niche" },
  { to: "/generate/script", Icon: Video, title: "Shorts Script Generator", desc: "30s / 60s / 2m" },
  { to: "/generate/thumbnail", Icon: ImageIcon, title: "Thumbnail Text", desc: "High-CTR phrases" },
  { to: "/generate/title", Icon: Youtube, title: "YouTube Title", desc: "Curiosity-gap titles" },
  { to: "/trending", Icon: TrendingUp, title: "Trending Ideas", desc: "AI-curated trends" },
];

function Create() {
  return (
    <>
      <AppShell>
        <header className="mb-5">
          <h1 className="text-2xl font-bold">Create</h1>
          <p className="text-sm text-muted-foreground">Pick a tool and go viral.</p>
        </header>
        <div className="space-y-3">
          {tools.map(({ to, Icon, title, desc }) => (
            <Link key={to} to={to} className="glass-strong rounded-2xl p-4 flex items-center gap-3 hover:ring-glow transition-all">
              <div className="size-11 rounded-xl gradient-bg flex items-center justify-center glow">
                <Icon className="size-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="font-semibold">{title}</div>
                <div className="text-xs text-muted-foreground">{desc}</div>
              </div>
              <span className="text-muted-foreground">→</span>
            </Link>
          ))}
        </div>
      </AppShell>
      <BottomNav />
    </>
  );
}
