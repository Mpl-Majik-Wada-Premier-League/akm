
-- Profiles table
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  email text,
  is_premium boolean not null default false,
  generations_count integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Profiles viewable by owner" on public.profiles
  for select using (auth.uid() = id);
create policy "Profiles updatable by owner" on public.profiles
  for update using (auth.uid() = id);
create policy "Profiles insertable by owner" on public.profiles
  for insert with check (auth.uid() = id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, username)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Generations table (history)
create table public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null,
  input jsonb not null default '{}'::jsonb,
  output text not null,
  is_favorite boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.generations enable row level security;

create policy "Generations viewable by owner" on public.generations
  for select using (auth.uid() = user_id);
create policy "Generations insertable by owner" on public.generations
  for insert with check (auth.uid() = user_id);
create policy "Generations updatable by owner" on public.generations
  for update using (auth.uid() = user_id);
create policy "Generations deletable by owner" on public.generations
  for delete using (auth.uid() = user_id);

create index generations_user_idx on public.generations(user_id, created_at desc);
